#!/usr/bin/env bash
# Hata durumunda çık
set -o errexit

# Bağımlılıkları yükle
pip install -r requirements.txt

# Statik dosyaları topla
python manage.py collectstatic --no-input

# Veritabanı migrasyonlarını uygula
python manage.py migrate

# Superuser oluştur
python manage.py createsu 