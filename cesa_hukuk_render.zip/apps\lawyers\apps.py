from django.apps import AppConfig


class LawyersConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.lawyers"
    verbose_name = "Avukatlar"
